package com.xyz.datadashboard.controller;

import com.xyz.datadashboard.cache.Cache;
import com.xyz.datadashboard.model.dao.DataDao;
import com.xyz.datadashboard.model.dvo.Data;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;


@RestController //= @ResponseBody + @Controller
//  @Controller
public class DataDashboardController {

    @Autowired
    private DataDao dataDao;

    @Autowired
    private Cache cache;

    @GetMapping("/data")
    public List<Data> getAllData(@RequestParam(name = "limit", required = false) String limit){
        if( (limit == null) || limit.isEmpty()){
            return dataDao.findAll();
        }else{
            return dataDao.findDataByLimit(Integer.valueOf(limit));
        }
    }

    @GetMapping("/data/client/{clientId}")
    public  List<Data> findDataByClientId(
            @PathVariable Long clientId,
            @RequestParam(name = "order_by", required = false) String field,
            @RequestParam(name = "sort", required = false) String sort,
            @RequestParam(name = "start", required = false) String start,
            @RequestParam(name = "end", required = false) String end){
        return dataDao.findByClientId(clientId, field, sort, start, end);
    }

    @PostMapping("/data")
    public Data createData(@RequestBody Data input){
        return dataDao.save(input);
    }

    @GetMapping("/data/{id}")
    public Data findDataById(@PathVariable Long id){
//        return dataDao.findById(id);
        String key = "data-" + id;
        if(cache.get(key) != null){
            return cache.get(key);
        }else{
            Data res = dataDao.findById(id);
            cache.put(key, res);
            return res;
        }
    }

    @PutMapping("/data/{id}")
    public Data updateDataById(@PathVariable Long id,@RequestBody Data data){
        Data original = dataDao.findById(id);
        if(original == null){
            throw new RuntimeException("id not exist");
            //return null
        }else {
            original.setClientId(data.getClientId());
            original.setTemperature(data.getTemperature());
            original.setStepCount(data.getStepCount());
            dataDao.save(original);

            String key = "data-" + original.getId();
            cache.put(key, original);

            return original;
        }
    }

//    @RequestMapping(path="/hello/{name}", method = RequestMethod.GET)
    @GetMapping("/hello/{name}")
//    @ResponseBody
    public String hello(@PathVariable String name){
        return "Hello " + name;
    }
}
