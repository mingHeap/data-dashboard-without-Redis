package com.xyz.datadashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataDashboardApplication {

    public static void main(String[] args) {
        SpringApplication.run(DataDashboardApplication.class, args);
    }

}
