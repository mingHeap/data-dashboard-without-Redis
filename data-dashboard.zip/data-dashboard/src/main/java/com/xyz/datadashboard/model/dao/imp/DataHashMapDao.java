//package com.xyz.datadashboard.model.dao.imp;
//
//import com.xyz.datadashboard.model.dao.DataDao;
//import com.xyz.datadashboard.model.dvo.Data;
//import org.springframework.stereotype.Component;
//
//import java.util.HashMap;
//import java.util.Map;
//
//@Component
//public class DataHashMapDao implements DataDao {
//
//    private Map<Long, Data> map = new HashMap<>();
//
//    @Override
//    public Data save(Data data) {
//
//        Long id = data.getId();
//
//        if(id == null || !(map.containsKey(id))){
//            id = map.size() + 1L;
//            data.setId(id);
//        }
//
//        map.put(id, data);
//
//        return data;
//    }
//
//    @Override
//    public Data findById(Long id) {
//        return map.get(id);
//    }
//}
