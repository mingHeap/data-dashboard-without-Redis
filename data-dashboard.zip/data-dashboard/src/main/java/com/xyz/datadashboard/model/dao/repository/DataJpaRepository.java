package com.xyz.datadashboard.model.dao.repository;

import com.xyz.datadashboard.model.dvo.Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DataJpaRepository extends JpaRepository<Data, Long> {

    @Query(value = "SELECT * FROM data LIMIT :limit", nativeQuery = true)
    List<Data> findAllByLimit(@Param("limit") Integer limit);


    List<Data> findByClientId(Long clientId);

    List<Data> findByClientIdOrderByStepCount(Long clientId);

    List<Data> findByClientIdOrderByStepCountDesc(Long clientId);

    List<Data> findByClientIdAndStepCountBetween(Long clientId, Integer start, Integer end);
}
