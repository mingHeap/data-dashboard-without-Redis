package com.xyz.datadashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataDashboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
